<?php  
if( ! defined( 'ABSPATH' ) ){
    exit; // Exit if accessed directly
}

echo '<div class="panel panel-view-themeoptions" style="display: none;"><div class="mfn-form mfn-form-themeoptions"></div></div>';