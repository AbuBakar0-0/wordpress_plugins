
<?php

do_action( 'in_wp_footer' );
do_action( 'wp_footer' );
do_action( 'wp_print_footer_scripts' );

?>
</body>
</html>